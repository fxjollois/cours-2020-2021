library(DBI)
cpt = dbConnect(RSQLite::SQLite(), "Comptoir2000.sqlite")

for (t in dbListTables(cpt)) {
  assign(t, dbReadTable(cpt, t))
}

dbDisconnect(cpt)
rm(t, cpt, test)
