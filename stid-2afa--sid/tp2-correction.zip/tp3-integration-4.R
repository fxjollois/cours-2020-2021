library(DBI)

dm = dbConnect(RSQLite::SQLite(), "datamart.sqlite")

# Extract et Transform par script 
# source("tp3-integration-3.R") # à faire avant pas fait

# Load des dimensions d'abord
dbAppendTable(dm, "DimDate", DimDate)
dbAppendTable(dm, "DimClient", DimClient)
dbAppendTable(dm, "DimProduit", DimProduit)
dbAppendTable(dm, "DimEmploye", DimEmploye)

# Load des tables de faits ensuite
dbAppendTable(dm, "FaitVente", FaitVente)
dbAppendTable(dm, "FaitCommande", FaitCommande)

dbDisconnect(dm)
rm(dm, DimClient, DimDate, DimEmploye, DimProduit, 
   FaitCommande, FaitVente)

