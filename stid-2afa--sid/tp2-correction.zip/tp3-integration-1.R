library(DBI)

dm = dbConnect(RSQLite::SQLite(), "datamart.sqlite")

# Création des tables
dbExecute(dm, "
CREATE TABLE DimDate (
  cleDate INT NOT NULL,
  Date DATE,
  Jour INT,
  Mois INT,
  Annee INT,
  Commentaires VARCHAR2(50),
  CONSTRAINT pk_DimDate PRIMARY KEY (cleDate)
);")
dbExecute(dm, "
CREATE VIEW DimDateCde AS
  SELECT cleDate cleDateCde, Date DateCde, Jour JourCde, Mois MoisCde, Annee AnneeCde
    FROM DimDate;
")
dbExecute(dm, "
CREATE VIEW DimDateEnvoi AS
  SELECT cleDate cleDateEnvoi, Date DateEnvoi, Jour JourEnvoi, Mois MoisEnvoi, Annee AnneeEnvoi
    FROM DimDate;
")
dbExecute(dm, "
CREATE VIEW DimDateLim AS
  SELECT cleDate cleDateLim, Date DateLim, Jour JourLim, Mois MoisLim, Annee AnneeLim
    FROM DimDate;
")
dbExecute(dm, "
CREATE TABLE DimClient (
  cleClient VARCHAR2(5) NOT NULL,
  NomClient VARCHAR2(50),
  VilleClient VARCHAR2(50),
  PaysClient VARCHAR2(50),
  CONSTRAINT pk_DimClient PRIMARY KEY (cleClient)
);
          ")
dbExecute(dm, "
CREATE TABLE DimProduit (
  cleProduit INT NOT NULL,
  NomProduit VARCHAR2(50),
  Fournisseur VARCHAR2(50),
  PaysFournisseur VARCHAR2(50),
  Categorie VARCHAR2(50),
  CONSTRAINT pk_DimProduit PRIMARY KEY (cleProduit)
);
          ")
dbExecute(dm, "
CREATE TABLE DimEmploye (
  cleEmploye INT NOT NULL,
  NomEmp VARCHAR2(50),
  PrenomEmp VARCHAR2(50),
  VilleEmp VARCHAR2(50),
  PaysEmp VARCHAR2(50),
  CONSTRAINT pk_DimEmploye PRIMARY KEY (cleEmploye)
);
          ")
dbExecute(dm, "
CREATE TABLE FaitVente (
  cleFaitVente INT NOT NULL,
  cleDate INT NOT NULL,
  cleClient VARCHAR2(5) NOT NULL,
  cleProduit INT NOT NULL,
  cleEmploye INT NOT NULL,
  Messager VARCHAR2(50),
  MontantTotal NUMBER,
  PrixUnit NUMBER,
  Quantite INT,
  MontantRemise NUMBER,
  CONSTRAINT pk_FaitVente PRIMARY KEY (cleFaitVente, cleDate, cleClient, cleProduit, cleEmploye),
  CONSTRAINT fk_FaitVente_DimDate FOREIGN KEY (cleDate) REFERENCES DimDate,
  CONSTRAINT fk_FaitVente_DimClient FOREIGN KEY (cleClient) REFERENCES DimClient,
  CONSTRAINT fk_FaitVente_DimProduit FOREIGN KEY (cleProduit) REFERENCES DimProduit,
  CONSTRAINT fk_FaitVente_DimEmploye FOREIGN KEY (cleEmploye) REFERENCES DimEmploye
);")
dbExecute(dm, "
CREATE TABLE FaitCommande (
  cleFaitCde INT NOT NULL,
  cleClient VARCHAR2(5) NOT NULL,
  cleEmploye INT NOT NULL,
  cleDateCde INT NOT NULL,
  cleDateEnvoi INT NOT NULL,
  cleDateLim INT NOT NULL,
  Messager VARCHAR2(50),
  MontantTotal NUMBER,
  Port NUMBER,
  CONSTRAINT pk_FaitCommande PRIMARY KEY (cleFaitCde, cleClient, cleEmploye, cleDateCde, cleDateEnvoi, cleDateLim),
  CONSTRAINT fk_FaitCommande_DimClient FOREIGN KEY (cleClient) REFERENCES DimClient,
  CONSTRAINT fk_FaitCommande_DimEmploye FOREIGN KEY (cleEmploye) REFERENCES DimEmploye,
  CONSTRAINT fk_FaitCommande_DimDate FOREIGN KEY (cleDateCde) REFERENCES DimDate,
  CONSTRAINT fk_FaitCommande_DimDate FOREIGN KEY (cleDateEnvoi) REFERENCES DimDate,
  CONSTRAINT fk_FaitCommande_DimDate FOREIGN KEY (cleDateLim) REFERENCES DimDate
);")

dbListTables(dm)

dbDisconnect(dm)
rm(dm)

