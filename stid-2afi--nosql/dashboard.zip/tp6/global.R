library(shiny)
library(shinydashboard)
library(leaflet)
library(mongolite)
library(geojsonio)
library(jsonlite)

load("data_global.RData")



m = mongo(
  collection = "restaurants", 
  db = "test"
)


onStop(function() {
  cat("Nettoyage à la fin de l'application\n")
  m$disconnect()
})


borough = geojson_read("new-york-city-boroughs.geojson", what = "sp")
pal = colorFactor("Set2", m$distinct("borough"))

infos = function(n, q, c, a, g) {
  msg = sprintf("<strong>%s</strong>
                <ul><li>Cuisine : %s</li>
                    <li>Adresse : %s %s, %s</li>
                    <li>Dernière évaluation
                        <ul><li>Date : %s</li>
                            <li>Grade obtenu : %s</li>
                            <li>Score : %s</li>
                        </ul>
                </ul>",
                n, c, a$building, a$street, q, g$date, g$grade, g$score)
  return (msg)
}



