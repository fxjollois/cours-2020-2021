
shinyUI(dashboardPage(
    dashboardHeader(),
    dashboardSidebar(
      sidebarMenu(
        menuItem("Global", tabName = "global", icon = icon("dashboard")),
        menuItem("Localisation", tabName = "carte", icon = icon("map"))
      )
    ),
    dashboardBody(
      tabItems(
        tabItem(
          "global",
          h2("Vue globale"),
          fluidRow(
            column(
              width = 7,
              box(
                width = 12,
                title = "Répartition des scores selon le grade obtenu",
                footer = "plus le score est élevé, plus les infractions sont nombreuses",
                status = "info",
                solidHeader = TRUE,
                plotOutput("global_distri")
              )
            ),
            column(
              width = 3,
              box(
                width = 12,
                title = "Nombre de restaurants par grades",
                solidHeader = TRUE,
                tableOutput("global_grade")
              ),
              box(
                width = 12,
                title = "Nombre de restaurants par quartier",
                solidHeader = TRUE,
                tableOutput("global_quartier")
              )
            ),
            column(
              width = 2,
              valueBox(
                width = 12,
                value = nb_restaurants,
                subtitle = "restaurants dans la base",
                icon = icon("utensils"),
                color = "aqua"
              ),
              valueBox(
                width = 12,
                value = nb_visites,
                subtitle = "évaluations",
                icon = icon("pencil-ruler"),
                color = "teal"
              ),
              valueBox(
                width = 12,
                value = nb_visites_0,
                subtitle = "évaluations avec score = 0",
                icon = icon("thumbs-up"),
                color = "green"
              ),
              valueBox(
                width = 12,
                value = nb_visites_bcp,
                subtitle = "évaluations avec score >= 50",
                icon = icon("thumbs-down"),
                color = "red"
              )
            )
          )
        ),
        tabItem(
          "carte",
          h2("Localisation des retaurants"),
          box(
            width = 3, 
            title = "Paramètres à choisir", solidHeader = T, status = "info",
            selectInput(inputId = "choix_quartier", 
                        label = "Quartier", 
                        choices = c("Tous", m$distinct("borough"))),
            selectInput(inputId = "choix_cuisine", 
                        label = "Cuisine", 
                        choices = c("Toutes", m$distinct("cuisine")))
          ),
          box(
            width = 9,
            title = "Carte des restaurants sélectionnés", solidHeader = T, status = "warning",
            leafletOutput("carte", height = "700px")
          )
        )
      )
    ),
    title = "Restaurants"
))
