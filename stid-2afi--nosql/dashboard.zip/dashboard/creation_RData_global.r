library(mongolite)
library(tidyverse)

rm(list = ls())
m = mongo(
  collection = "restaurants", 
  db = "test"
)

################################################# pré-Calculs pour UI
nb_restaurants = m$count()
nb_visites = m$aggregate(
  '[ 
  { "$unwind": "$grades" }, 
  { "$group": { "_id": "tous", "nb": { "$sum": 1 }}}
]')$nb
nb_visites_0 = m$aggregate(
  '[ 
  { "$unwind": "$grades" }, 
  { "$match": { "grades.score": 0 }},
  { "$group": { "_id": "tous", "nb": { "$sum": 1 }}}
]')$nb
nb_visites_bcp = m$aggregate(
  '[ 
  { "$unwind": "$grades" }, 
  { "$match": { "grades.score": { "$gte": 50 } }},
  { "$group": { "_id": "tous", "nb": { "$sum": 1 }}}
]')$nb

################################################# pré-Calculs pour SERVER
df_grade_score = m$aggregate(
'[
{ "$unwind": "$grades" },
{ "$project": { "grade": "$grades.grade", "score": "$grades.score" }}
]')
plot_grade_score = ggplot(df_grade_score, aes(grade, score, fill = grade)) +
  geom_boxplot(show.legend = FALSE) +
  theme_minimal() +
  labs(x = "", y = "Score")

df_grade_nb = m$aggregate(
  '[ 
  { "$project" : {
    "eval": { "$arrayElemAt": [ "$grades", 0 ]}
  }},
  { "$sortByCount": "$eval.grade" },
  { "$sort": { "_id": 1 }},
  { "$project": { "Grade": "$_id", "Nb restaurants": "$count", "_id": 0 }}
  ]'
)
df_quartier_nb = m$aggregate(
  '[ 
  { "$sortByCount": "$borough" },
  { "$project": { "Quartier": "$_id", "Nb restaurants": "$count", "_id": 0 }}
  ]'
)

m$disconnect()
rm(m)

# Tous ces dataframes et ce graphiques étant fixes, il est préférable de les stocker dans un fichier RData
save.image(file = "data_global.RData")
rm(list = ls())

