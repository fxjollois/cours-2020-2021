library(shiny)

shinyServer(function(input, output) {
  output$global_distri <- renderPlot({
    print(plot_grade_score)
  })
  output$global_grade <- renderTable({
    df_grade_nb
  })
  output$global_quartier <- renderTable({
    df_quartier_nb
  })
  
  
  restaurants_choisis <- reactive({
    # on demande à MongoDB les restaurants selon les critères choisis
    requete = list(
      list(
        "$addFields" = list(
          "lng" = list("$arrayElemAt" = list("$address.coord", 0)),
          "lat" = list("$arrayElemAt" = list("$address.coord", 1)),
          "eval" = list("$arrayElemAt" = list("$grades", 0))
        )
      )
    )
    if (input$choix_quartier != "Tous") {
      requete[[length(requete) + 1]] = list("$match" = list("borough" = input$choix_quartier))
    }
    if (input$choix_cuisine != "Toutes") {
      requete[[length(requete) + 1]] = list("$match" = list("cuisine" = input$choix_cuisine))
    }
    requete_json = toJSON(requete, auto_unbox = T)
    res = m$aggregate(requete_json)
    return(res)
  })
  output$carte <- renderLeaflet({
    res = restaurants_choisis()
    leaflet(res) %>% addTiles()  %>%
      setView(-74, 40.70, zoom = 10) %>%
      addPolygons(data = borough, stroke = TRUE, color = "black", weight = 2,
                  fillOpacity = .5, fillColor = ~pal(name),
                  label = ~name) %>%
      addMarkers(lng = ~lng, lat = ~lat,
                 label = ~paste0(name, " (", lng, ", ", lat, ")"),
                 popup = ~infos(name, borough, cuisine, address, eval),
                 clusterOptions = markerClusterOptions()) %>%
      addLegend(pal = pal, values = ~borough, opacity = 1, title = "Quartier")
  })
  
})
